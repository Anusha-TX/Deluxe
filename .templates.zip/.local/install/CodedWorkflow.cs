using System;
using System.Collections.Generic;
using System.Data;
using UiPath.CodedWorkflows;
using UiPath.Core;
using UiPath.Core.Activities.Storage;
using UiPath.Orchestrator.Client.Models;
using UiPath.Testing;
using UiPath.Testing.Activities.TestData;
using UiPath.Testing.Activities.TestDataQueues.Enums;
using UiPath.Testing.Enums;
using UiPath.CodedWorkflows.DescriptorIntegration;

namespace Deluxe_ReusableLibrary
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{typeof(UiPath.Core.Activities.API.ISystemService), typeof(UiPath.Testing.API.ITestingService)};
        }

        protected UiPath.Core.Activities.API.ISystemService system { get => serviceContainer.Resolve<UiPath.Core.Activities.API.ISystemService>(); }

        protected UiPath.Testing.API.ITestingService testing { get => serviceContainer.Resolve<UiPath.Testing.API.ITestingService>(); }
    }
}

namespace Deluxe_ReusableLibrary.ObjectRepository
{
    public static class Descriptors
    {
        public static class Deluxe_Payments_Platform
        {
            public static _Implementation._Deluxe_Payments_Platform.__DPP_CustomerVault DPP_CustomerVault { get; private set; } = new _Implementation._Deluxe_Payments_Platform.__DPP_CustomerVault();
            public static _Implementation._Deluxe_Payments_Platform.__DPP_Payments DPP_Payments { get; private set; } = new _Implementation._Deluxe_Payments_Platform.__DPP_Payments();
            public static _Implementation._Deluxe_Payments_Platform.__DPP_SideMenu DPP_SideMenu { get; private set; } = new _Implementation._Deluxe_Payments_Platform.__DPP_SideMenu();
        }
    }
}

namespace Deluxe_ReusableLibrary._Implementation
{
    internal class ScreenDescriptorDefinition : IScreenDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }
    }

    internal class ElementDescriptorDefinition : IElementDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }

        public IElementDescriptor ParentElement { get; set; }

        public IElementDescriptor Element { get; set; }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __Customer_Vault_Details : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_Vault_Details(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/a7gMW3UxKU6Y5mU_0jcu1g", DisplayName = "Customer Vault Details", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_Address_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_Address_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/D707tSMH8UKH9UsHovR2rA", DisplayName = "CV_CreateNewCustomer_Address_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_Cancel_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_Cancel_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/7CrWwtcbMEerO03tmLKzNg", DisplayName = "CV_CreateNewCustomer_Cancel_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_City_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_City_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/0EXAW7X2s0Gh3B2WrHjnKA", DisplayName = "CV_CreateNewCustomer_City_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_Create_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_Create_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/JCPEDw0AK0y-vXAFw9J9Nw", DisplayName = "CV_CreateNewCustomer_Create_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_Email_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_Email_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/QYw_h8bKgUaxzrQatMVKvg", DisplayName = "CV_CreateNewCustomer_Email_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_FirstName_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_FirstName_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/VNF7nUwdBEmXigtL9A9pzg", DisplayName = "CV_CreateNewCustomer_FirstName_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_LastName_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_LastName_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/fik2sN-FFkq6uO4EYvlmpA", DisplayName = "CV_CreateNewCustomer_LastName_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_PostalCode_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_PostalCode_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Hw1Jd-Mk_k20PbPbdznJxA", DisplayName = "CV_CreateNewCustomer_PostalCode_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_SearchMerchant_Combo : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_SearchMerchant_Combo(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/b6ucTUzCG02uAN4_nVGfVw", DisplayName = "CV_CreateNewCustomer_SearchMerchant_Combo", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_SearchMerchant_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_SearchMerchant_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/0wJKj6uICUKcoYodn-IPbQ", DisplayName = "CV_CreateNewCustomer_SearchMerchant_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_State_Combo : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_State_Combo(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/efMcP6o08k-zrrI9gJpMMA", DisplayName = "CV_CreateNewCustomer_State_Combo", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_CreateNewCustomer_State_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_State_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/zjAUBDmJ7EKPFh_ODTn_Sw", DisplayName = "CV_CreateNewCustomer_State_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_ShippingInfo_Address_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_ShippingInfo_Address_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/YQKjV-d1-kSCsIbHHk70IQ", DisplayName = "CV_ShippingInfo_Address_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_ShippingInfo_City_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_ShippingInfo_City_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/FL73xa-Fy0GDR_tr_MVfrQ", DisplayName = "CV_ShippingInfo_City_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_ShippingInfo_FirstName_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_ShippingInfo_FirstName_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/TxXXYF90tEyTiOTOcAorxQ", DisplayName = "CV_ShippingInfo_FirstName_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_ShippingInfo_LastName_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_ShippingInfo_LastName_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/pKqpAvjE2kigrsg_1dvRcQ", DisplayName = "CV_ShippingInfo_LastName_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_ShippingInfo_State_Combo : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_ShippingInfo_State_Combo(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/UvK8RT2grkWVogoMSxHLQA", DisplayName = "CV_ShippingInfo_State_Combo", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_ShippingInfo_State_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_ShippingInfo_State_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/DC1oLQ8Vak2u6Eto2aArGw", DisplayName = "CV_ShippingInfo_State_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_ShippingInfo_Toggle_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_ShippingInfo_Toggle_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/wEaWiTFO4Um4hX98krN9xA", DisplayName = "CV_ShippingInfo_Toggle_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button
    {
        public class __CV_ShippingInfo_Zipcode_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_ShippingInfo_Zipcode_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/2-eFKKZfFkqFg_JEInaICA", DisplayName = "CV_ShippingInfo_Zipcode_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault
    {
        public class __CustomerVault_CreateNewCustomer_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CustomerVault_CreateNewCustomer_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/jqjeccLzg0Wt2eGJGW-6bA", DisplayName = "CustomerVault_CreateNewCustomer_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Customer_Vault_Details = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__Customer_Vault_Details(screenDescriptor, this);
                CV_CreateNewCustomer_Address_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_Address_Input(screenDescriptor, this);
                CV_CreateNewCustomer_Cancel_Button = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_Cancel_Button(screenDescriptor, this);
                CV_CreateNewCustomer_City_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_City_Input(screenDescriptor, this);
                CV_CreateNewCustomer_Create_Button = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_Create_Button(screenDescriptor, this);
                CV_CreateNewCustomer_Email_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_Email_Input(screenDescriptor, this);
                CV_CreateNewCustomer_FirstName_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_FirstName_Input(screenDescriptor, this);
                CV_CreateNewCustomer_LastName_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_LastName_Input(screenDescriptor, this);
                CV_CreateNewCustomer_PostalCode_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_PostalCode_Input(screenDescriptor, this);
                CV_CreateNewCustomer_SearchMerchant_Combo = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_SearchMerchant_Combo(screenDescriptor, this);
                CV_CreateNewCustomer_SearchMerchant_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_SearchMerchant_Input(screenDescriptor, this);
                CV_CreateNewCustomer_State_Combo = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_State_Combo(screenDescriptor, this);
                CV_CreateNewCustomer_State_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_State_Input(screenDescriptor, this);
                CV_ShippingInfo_Address_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_Address_Input(screenDescriptor, this);
                CV_ShippingInfo_City_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_City_Input(screenDescriptor, this);
                CV_ShippingInfo_FirstName_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_FirstName_Input(screenDescriptor, this);
                CV_ShippingInfo_LastName_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_LastName_Input(screenDescriptor, this);
                CV_ShippingInfo_State_Combo = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_State_Combo(screenDescriptor, this);
                CV_ShippingInfo_State_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_State_Input(screenDescriptor, this);
                CV_ShippingInfo_Toggle_Button = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_Toggle_Button(screenDescriptor, this);
                CV_ShippingInfo_Zipcode_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_Zipcode_Input(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__Customer_Vault_Details Customer_Vault_Details { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_Address_Input CV_CreateNewCustomer_Address_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_Cancel_Button CV_CreateNewCustomer_Cancel_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_City_Input CV_CreateNewCustomer_City_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_Create_Button CV_CreateNewCustomer_Create_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_Email_Input CV_CreateNewCustomer_Email_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_FirstName_Input CV_CreateNewCustomer_FirstName_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_LastName_Input CV_CreateNewCustomer_LastName_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_PostalCode_Input CV_CreateNewCustomer_PostalCode_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_SearchMerchant_Combo CV_CreateNewCustomer_SearchMerchant_Combo { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_SearchMerchant_Input CV_CreateNewCustomer_SearchMerchant_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_State_Combo CV_CreateNewCustomer_State_Combo { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_CreateNewCustomer_State_Input CV_CreateNewCustomer_State_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_Address_Input CV_ShippingInfo_Address_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_City_Input CV_ShippingInfo_City_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_FirstName_Input CV_ShippingInfo_FirstName_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_LastName_Input CV_ShippingInfo_LastName_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_State_Combo CV_ShippingInfo_State_Combo { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_State_Input CV_ShippingInfo_State_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_Toggle_Button CV_ShippingInfo_Toggle_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault._CustomerVault_CreateNewCustomer_Button.__CV_ShippingInfo_Zipcode_Input CV_ShippingInfo_Zipcode_Input { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault
    {
        public class __CustomerVault_SearchMerchant_Combo_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CustomerVault_SearchMerchant_Combo_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/8R0uWUF2TUi8yinVpNWfJA", DisplayName = "CustomerVault_SearchMerchant_Combo'", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_CustomerVault
    {
        public class __CustomerVault_SearchMerchant_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CustomerVault_SearchMerchant_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/weL91QU1iU-dTY6ItxenmA", DisplayName = "CustomerVault_SearchMerchant_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform
    {
        public class __DPP_CustomerVault : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __DPP_CustomerVault()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/AvmCtlRsWEiYMM2hpio-bA", DisplayName = "DPP_CustomerVault", Screen = this};
                CustomerVault_CreateNewCustomer_Button = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault.__CustomerVault_CreateNewCustomer_Button(this, null);
                CustomerVault_SearchMerchant_Combo_ = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault.__CustomerVault_SearchMerchant_Combo_(this, null);
                CustomerVault_SearchMerchant_Input = new _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault.__CustomerVault_SearchMerchant_Input(this, null);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault.__CustomerVault_CreateNewCustomer_Button CustomerVault_CreateNewCustomer_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault.__CustomerVault_SearchMerchant_Combo_ CustomerVault_SearchMerchant_Combo_ { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_CustomerVault.__CustomerVault_SearchMerchant_Input CustomerVault_SearchMerchant_Input { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Add_Preset_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Add_Preset_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/8qZWxT3GwEiHwvqNRYzyEw", DisplayName = "Add Preset Item", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Add_Quick_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Add_Quick_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/CDJ5Mr8PfEOZj9pNoLx5lg", DisplayName = "Add Quick Item", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Additional_Fields._Discount_Rate_List
    {
        public class __Enter_Discount_Rate : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Enter_Discount_Rate(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/jJoUH8v1kkeoSX0XAJNF5Q", DisplayName = "Enter Discount Rate", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Additional_Fields
    {
        public class __Discount_Rate_List : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Discount_Rate_List(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/rzpm-c__9kypze_HCHGKJA", DisplayName = "Discount Rate List", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Enter_Discount_Rate = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields._Discount_Rate_List.__Enter_Discount_Rate(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields._Discount_Rate_List.__Enter_Discount_Rate Enter_Discount_Rate { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Additional_Fields
    {
        public class __Invoice__ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Invoice__(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/UiIDsYM-G0mZZlj1eFEpvQ", DisplayName = "Invoice #", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Additional_Fields
    {
        public class __Order_Note : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Order_Note(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/x9Glboej1E-rTEZmj6PqZw", DisplayName = "Order Note", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Additional_Fields
    {
        public class __Tax_Rate_List : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Tax_Rate_List(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/1uCgDiR1t0mQvoAlsngIBg", DisplayName = "Tax Rate List", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Additional_Fields
    {
        public class __Tax_Rate_List_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Tax_Rate_List_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/ofvBP6NzVEa5YMzGhMdBEQ", DisplayName = "Tax Rate List Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Additional_Fields : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Additional_Fields(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/D0oS3rHFX02N_OvPVfWncw", DisplayName = "Additional Fields", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Discount_Rate_List = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Discount_Rate_List(screenDescriptor, this);
                Invoice__ = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Invoice__(screenDescriptor, this);
                Order_Note = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Order_Note(screenDescriptor, this);
                Tax_Rate_List = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Tax_Rate_List(screenDescriptor, this);
                Tax_Rate_List_Input = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Tax_Rate_List_Input(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Discount_Rate_List Discount_Rate_List { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Invoice__ Invoice__ { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Order_Note Order_Note { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Tax_Rate_List Tax_Rate_List { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Additional_Fields.__Tax_Rate_List_Input Tax_Rate_List_Input { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Authorization_Code : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Authorization_Code(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/dc85xAn0qk--kPnthywczg", DisplayName = "Authorization Code", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Charge_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Charge_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/hskwN9O0Y0KOg0OmmSrxvQ", DisplayName = "Charge Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Close_Toast_Message : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Close_Toast_Message(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/bMRusudP1kqOQmvybY5YAQ", DisplayName = "Close Toast Message", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Country : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Country(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/9T_ZO4882kKqHXZw1AcQFQ", DisplayName = "Country", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Create_Vault_Customer : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Create_Vault_Customer(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/qh6fT_edV0aHSzACqXOBvw", DisplayName = "Create Vault Customer", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Customer_Address : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_Address(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/XKE49LyW8UiRNk-NtEnLsg", DisplayName = "Customer Address", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Customer_City : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_City(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/FlFgavE0Akq-rWz4FnL5Aw", DisplayName = "Customer City", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Customer_Info_Arrow_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_Info_Arrow_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/CvU2YpmIgEKuI0X-pVV62A", DisplayName = "Customer Info Arrow Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Customer_State
    {
        public class __Customer_State_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_State_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/7i7LbzoeZU-gJaW4GX3lbw", DisplayName = "Customer State Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Customer_State : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_State(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/x8drs0oddEiR1nalSmy8Wg", DisplayName = "Customer State", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Customer_State_Input = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Customer_State.__Customer_State_Input(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Customer_State.__Customer_State_Input Customer_State_Input { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Customer_Zip_Code : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_Zip_Code(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Z5946QQv30OGc8MFuGdK_w", DisplayName = "Customer Zip Code", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Email : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Email(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/jjbjdqWe00uuoafN8MjFkA", DisplayName = "Email", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __Address : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Address(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/cqzH9u15tkilnMIk1DUEvA", DisplayName = "Address", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __City : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __City(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/iyqJxJzs5ECLBAePf1NlEQ", DisplayName = "City", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __Country : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Country(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/_yNnKePuM0633dXu0oRjrA", DisplayName = "Country", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __Email : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Email(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/2fKlqL-jf0OrTLLd9vxB0Q", DisplayName = "Email", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __First_Name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __First_Name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/mNPAixuNu0OqnxIXSFz1yA", DisplayName = "First Name", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __Last_Name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Last_Name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/jXw3GLiMjEqn890Ih-KXVg", DisplayName = "Last Name", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __Phone_Number : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Phone_Number(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/ewhSDBkY8UyCTqIcqTCXvw", DisplayName = "Phone Number", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __Shipping_Method : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Shipping_Method(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/FZfbiOvB7EevgHRpS-Ih4A", DisplayName = "Shipping Method", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __State : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __State(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Mxic_kUG40iXhx79tGz7gA", DisplayName = "State", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address
    {
        public class __Zip_Code : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Zip_Code(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/E5HsFY9BxECi_8FEQOOgGw", DisplayName = "Zip Code", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Enter_Alternate_Shipping_Address : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Enter_Alternate_Shipping_Address(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/pHzrAwaaTkKwDsID0YHLZw", DisplayName = "Enter Alternate Shipping Address", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Address = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Address(screenDescriptor, this);
                City = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__City(screenDescriptor, this);
                Country = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Country(screenDescriptor, this);
                Email = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Email(screenDescriptor, this);
                First_Name = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__First_Name(screenDescriptor, this);
                Last_Name = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Last_Name(screenDescriptor, this);
                Phone_Number = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Phone_Number(screenDescriptor, this);
                Shipping_Method = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Shipping_Method(screenDescriptor, this);
                State = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__State(screenDescriptor, this);
                Zip_Code = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Zip_Code(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Address Address { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__City City { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Country Country { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Email Email { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__First_Name First_Name { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Last_Name Last_Name { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Phone_Number Phone_Number { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Shipping_Method Shipping_Method { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__State State { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Enter_Alternate_Shipping_Address.__Zip_Code Zip_Code { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __First_Name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __First_Name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/0AcVut4PSEWP55Ic6zPgjA", DisplayName = "First Name", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Last_Name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Last_Name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/gUD8T7x_R0OwhDRook6X2g", DisplayName = "Last Name", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __New_Sale_Item_Added : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __New_Sale_Item_Added(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/KGXYJBr1nUW0_RhVG3FhYw", DisplayName = "New Sale Item Added", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Card_Icon : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Card_Icon(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/f2r-Mvah0U-iisHbS_i-Gg", DisplayName = "Card Icon", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Card_Last_4_Number : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Card_Last_4_Number(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Rt6C7CaKfUiZ0zYGG1tNpQ", DisplayName = "Card Last 4 Number", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Clear_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Clear_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/WvRlv_J0NUuT8aH5Gom7dg", DisplayName = "Clear Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Customer_Info : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_Info(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/1vCcjDrTTk6qaaZginJ9SA", DisplayName = "Customer Info", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Discount : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Discount(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/3LQe-D_OFE-C-9-f9LoGcQ", DisplayName = "Discount", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Edit_For_Each_Sale_Item_in_Order_Summary : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Edit_For_Each_Sale_Item_in_Order_Summary(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/XZnqEc3_sESdXlHpFrI6pA", DisplayName = "Edit For Each Sale Item in Order Summary", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __For_Each_Sale_Item_Element : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __For_Each_Sale_Item_Element(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/nWGsAztC3UukiWbs6sJ8iQ", DisplayName = "For Each Sale Item Element", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Order_Note : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Order_Note(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/2yy1WOxkbUCBjWOF9D-7cw", DisplayName = "Order Note", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __OrderSummary : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __OrderSummary(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/NIEkDAyfIUOXGdypv91akQ", DisplayName = "OrderSummary", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Remove_Surcharge : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Remove_Surcharge(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/89EiWlQ9UEK7pvxdIqYTzQ", DisplayName = "Remove Surcharge", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Sale_Items : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sale_Items(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/a45DRVgoq0KMWL0eJVR_2Q", DisplayName = "Sale Items", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Sale_Items_Table_Data : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sale_Items_Table_Data(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Hue0g8s1vUy1XOsOmPcNXQ", DisplayName = "Sale Items Table Data", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __SaleItemQuantity : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __SaleItemQuantity(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/t8ybCf7Zbk--0MNA_iTliw", DisplayName = "SaleItemQuantity", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Sub_Total : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sub_Total(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/PtxjAAjwPE6TpWFe6Ij0aQ", DisplayName = "Sub Total", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Surcharge_Amount : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Surcharge_Amount(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/KM3hwHxFc0y8aIkWz5WsQg", DisplayName = "Surcharge Amount", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Tax_Amount : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Tax_Amount(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/9YZxRoYJnk-7uuZ1WJf1Hw", DisplayName = "Tax Amount", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Total_Amount : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Total_Amount(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/5SRwAN8OukqBLbihuMt4SQ", DisplayName = "Total Amount", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Transaction_Details : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Transaction_Details(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/9Qg9VS-TtUWCOeRLn86kdw", DisplayName = "Transaction Details", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._OrderSummary
    {
        public class __Update_Sale_Item_Quantity : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Update_Sale_Item_Quantity(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/p0lAgs2JxUKpzaHwNG9ECA", DisplayName = "Update Sale Item Quantity", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __OrderSummary : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __OrderSummary(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/ML1w9rHayEC3u9bgLctqDw", DisplayName = "OrderSummary", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Card_Icon = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Card_Icon(screenDescriptor, this);
                Card_Last_4_Number = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Card_Last_4_Number(screenDescriptor, this);
                Clear_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Clear_Button(screenDescriptor, this);
                Customer_Info = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Customer_Info(screenDescriptor, this);
                Discount = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Discount(screenDescriptor, this);
                Edit_For_Each_Sale_Item_in_Order_Summary = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Edit_For_Each_Sale_Item_in_Order_Summary(screenDescriptor, this);
                For_Each_Sale_Item_Element = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__For_Each_Sale_Item_Element(screenDescriptor, this);
                Order_Note = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Order_Note(screenDescriptor, this);
                OrderSummary = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__OrderSummary(screenDescriptor, this);
                Remove_Surcharge = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Remove_Surcharge(screenDescriptor, this);
                Sale_Items = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Sale_Items(screenDescriptor, this);
                Sale_Items_Table_Data = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Sale_Items_Table_Data(screenDescriptor, this);
                SaleItemQuantity = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__SaleItemQuantity(screenDescriptor, this);
                Sub_Total = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Sub_Total(screenDescriptor, this);
                Surcharge_Amount = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Surcharge_Amount(screenDescriptor, this);
                Tax_Amount = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Tax_Amount(screenDescriptor, this);
                Total_Amount = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Total_Amount(screenDescriptor, this);
                Transaction_Details = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Transaction_Details(screenDescriptor, this);
                Update_Sale_Item_Quantity = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Update_Sale_Item_Quantity(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Card_Icon Card_Icon { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Card_Last_4_Number Card_Last_4_Number { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Clear_Button Clear_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Customer_Info Customer_Info { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Discount Discount { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Edit_For_Each_Sale_Item_in_Order_Summary Edit_For_Each_Sale_Item_in_Order_Summary { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__For_Each_Sale_Item_Element For_Each_Sale_Item_Element { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Order_Note Order_Note { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__OrderSummary OrderSummary { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Remove_Surcharge Remove_Surcharge { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Sale_Items Sale_Items { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Sale_Items_Table_Data Sale_Items_Table_Data { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__SaleItemQuantity SaleItemQuantity { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Sub_Total Sub_Total { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Surcharge_Amount Surcharge_Amount { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Tax_Amount Tax_Amount { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Total_Amount Total_Amount { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Transaction_Details Transaction_Details { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._OrderSummary.__Update_Sale_Item_Quantity Update_Sale_Item_Quantity { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __AccNickName : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __AccNickName(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/1wWih7fqVk26DlFW1jdC8A", DisplayName = "AccNickName", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info._Account_Type
    {
        public class __Type_Into_Account_Type : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Type_Into_Account_Type(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/k5u9go3PckKs9FKHfwsqDQ", DisplayName = "Type Into Account Type", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __Account_Type : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Account_Type(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/7WFJBa8MtECKZvkmdBA79A", DisplayName = "Account Type", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Type_Into_Account_Type = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info._Account_Type.__Type_Into_Account_Type(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info._Account_Type.__Type_Into_Account_Type Type_Into_Account_Type { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __AccountNumber : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __AccountNumber(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/PuiDt-sMpEGTF8utssOO1w", DisplayName = "AccountNumber", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __AmountTender : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __AmountTender(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/zME6vpjClECVh3l5LAQPCQ", DisplayName = "AmountTender", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __Card_Expiration : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Card_Expiration(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/v0h_wUoHxk2ibTkKwaoCRA", DisplayName = "Card Expiration", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info._Card_Number
    {
        public class __Enter_Valid_Card_Number : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Enter_Valid_Card_Number(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/If8T2Ly6u0KasQs-pDtsRg", DisplayName = "Enter Valid Card Number", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __Card_Number : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Card_Number(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/uhSQyasnmEmnZEHktYeuhQ", DisplayName = "Card Number", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Enter_Valid_Card_Number = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info._Card_Number.__Enter_Valid_Card_Number(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info._Card_Number.__Enter_Valid_Card_Number Enter_Valid_Card_Number { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __Change : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Change(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/31iCO6sHvUmEBFD2r-707w", DisplayName = "Change", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __CheckNumber : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CheckNumber(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/FNemKsggkEqXY10lXcMi1Q", DisplayName = "CheckNumber", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __CVV : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CVV(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/O-Zubov3zk208Vl79UvmLA", DisplayName = "CVV", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __Payment_Type : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payment_Type(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/qlQGzg4GvEenl6WiFn-rDw", DisplayName = "Payment Type", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payment_Info
    {
        public class __RoutingNumber : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __RoutingNumber(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/2cOxbaaIek22hLD44l1ACw", DisplayName = "RoutingNumber", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Payment_Info : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payment_Info(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Rg3BycY97EiPnq9lVtWhzQ", DisplayName = "Payment Info", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                AccNickName = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__AccNickName(screenDescriptor, this);
                Account_Type = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Account_Type(screenDescriptor, this);
                AccountNumber = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__AccountNumber(screenDescriptor, this);
                AmountTender = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__AmountTender(screenDescriptor, this);
                Card_Expiration = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Card_Expiration(screenDescriptor, this);
                Card_Number = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Card_Number(screenDescriptor, this);
                Change = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Change(screenDescriptor, this);
                CheckNumber = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__CheckNumber(screenDescriptor, this);
                CVV = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__CVV(screenDescriptor, this);
                Payment_Type = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Payment_Type(screenDescriptor, this);
                RoutingNumber = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__RoutingNumber(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__AccNickName AccNickName { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Account_Type Account_Type { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__AccountNumber AccountNumber { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__AmountTender AmountTender { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Card_Expiration Card_Expiration { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Card_Number Card_Number { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Change Change { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__CheckNumber CheckNumber { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__CVV CVV { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__Payment_Type Payment_Type { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payment_Info.__RoutingNumber RoutingNumber { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button
    {
        public class __ConfirmationMessage_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __ConfirmationMessage_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/SHj2x8rNtU-nbrGyJTURXw", DisplayName = "ConfirmationMessage Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button
    {
        public class __ExpiresIn_Combo : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __ExpiresIn_Combo(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Md4iv_Q1w02UjZFqjsc9rg", DisplayName = "ExpiresIn Combo", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button
    {
        public class __CopyLink_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CopyLink_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/YTOIS9kV50O9qLyj3PXrDw", DisplayName = "CopyLink Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button
    {
        public class __CopyQRCode : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CopyQRCode(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/ofVYNCzIq0egAUH7171ECA", DisplayName = "CopyQRCode", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button
    {
        public class __DownloadQRCode : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __DownloadQRCode(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Bonxg6aYqUKCqjzf8r7GLw", DisplayName = "DownloadQRCode", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button
    {
        public class __Link_Get_Text : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Link_Get_Text(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/ioYsEClZDkuaJix78OYw4Q", DisplayName = "Link Get Text", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button
    {
        public class __GenerateLink_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __GenerateLink_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/nUqEi7z0dUOsjzvNTKemVg", DisplayName = "GenerateLink Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                CopyLink_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button.__CopyLink_Button(screenDescriptor, this);
                CopyQRCode = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button.__CopyQRCode(screenDescriptor, this);
                DownloadQRCode = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button.__DownloadQRCode(screenDescriptor, this);
                Link_Get_Text = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button.__Link_Get_Text(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button.__CopyLink_Button CopyLink_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button.__CopyQRCode CopyQRCode { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button.__DownloadQRCode DownloadQRCode { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._GenerateLink_Button.__Link_Get_Text Link_Get_Text { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button
    {
        public class __PreviewLink_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __PreviewLink_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/3exZTaTO4EyQ4yINcruMpw", DisplayName = "PreviewLink Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._SendPaymentLink_Button
    {
        public class __Message_Close_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Message_Close_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/iYiFATuQxkaaYroDW2XH9Q", DisplayName = "Message Close Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._SendPaymentLink_Button
    {
        public class __PaymentLinkSentSuccess_Message : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __PaymentLinkSentSuccess_Message(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/zxgISgV7OkqaPzChtO_rPg", DisplayName = "PaymentLinkSentSuccess Message", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button
    {
        public class __SendPaymentLink_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __SendPaymentLink_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/CwjcjvxqSkeliXcFpKrjIg", DisplayName = "SendPaymentLink Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Message_Close_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._SendPaymentLink_Button.__Message_Close_Button(screenDescriptor, this);
                PaymentLinkSentSuccess_Message = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._SendPaymentLink_Button.__PaymentLinkSentSuccess_Message(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._SendPaymentLink_Button.__Message_Close_Button Message_Close_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button._SendPaymentLink_Button.__PaymentLinkSentSuccess_Message PaymentLinkSentSuccess_Message { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button
    {
        public class __ViewReport_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __ViewReport_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/mGTodLpCFUKvBwSkwgZuqA", DisplayName = "ViewReport Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __PaymentLink_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __PaymentLink_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/4vstsEAnEU-1aUSyW52tHw", DisplayName = "PaymentLink Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                ConfirmationMessage_Input = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__ConfirmationMessage_Input(screenDescriptor, this);
                ExpiresIn_Combo = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__ExpiresIn_Combo(screenDescriptor, this);
                GenerateLink_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__GenerateLink_Button(screenDescriptor, this);
                PreviewLink_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__PreviewLink_Button(screenDescriptor, this);
                SendPaymentLink_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__SendPaymentLink_Button(screenDescriptor, this);
                ViewReport_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__ViewReport_Button(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__ConfirmationMessage_Input ConfirmationMessage_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__ExpiresIn_Combo ExpiresIn_Combo { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__GenerateLink_Button GenerateLink_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__PreviewLink_Button PreviewLink_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__SendPaymentLink_Button SendPaymentLink_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._PaymentLink_Button.__ViewReport_Button ViewReport_Button { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Payments_Label : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_Label(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/8Jog9BbQ8EK2jkuwb664CQ", DisplayName = "Payments Label", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction
    {
        public class __File_name_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __File_name_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/quHJOkbA80aqlCyj8TwQkg", DisplayName = "File name Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction
    {
        public class __Payments_BatchTransaction_ChooseFile_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_BatchTransaction_ChooseFile_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/ajruhlmVk02Dt2FD9Sjuvw", DisplayName = "Payments_BatchTransaction_ChooseFile_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction
    {
        public class __Payments_BatchTransaction_Clear_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_BatchTransaction_Clear_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/EytsD3nYS0q5hGE79c2Krg", DisplayName = "Payments_BatchTransaction_Clear_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction
    {
        public class __Payments_BatchTransaction_UploadFile_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_BatchTransaction_UploadFile_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/JACtGhTyLEK-AVhM73B7xA", DisplayName = "Payments_BatchTransaction_UploadFile_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction
    {
        public class __Your_batch_file_hasbeen_successfully : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Your_batch_file_hasbeen_successfully(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Ej9T8mVq2U23IlTxVn68gw", DisplayName = "Your batch file hasbeen successfully", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Payments_BatchTransaction : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_BatchTransaction(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/A-b-9S-ah0q1do403wjVsw", DisplayName = "Payments_BatchTransaction", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                File_name_Input = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__File_name_Input(screenDescriptor, this);
                Payments_BatchTransaction_ChooseFile_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__Payments_BatchTransaction_ChooseFile_Button(screenDescriptor, this);
                Payments_BatchTransaction_Clear_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__Payments_BatchTransaction_Clear_Button(screenDescriptor, this);
                Payments_BatchTransaction_UploadFile_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__Payments_BatchTransaction_UploadFile_Button(screenDescriptor, this);
                Your_batch_file_hasbeen_successfully = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__Your_batch_file_hasbeen_successfully(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__File_name_Input File_name_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__Payments_BatchTransaction_ChooseFile_Button Payments_BatchTransaction_ChooseFile_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__Payments_BatchTransaction_Clear_Button Payments_BatchTransaction_Clear_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__Payments_BatchTransaction_UploadFile_Button Payments_BatchTransaction_UploadFile_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_BatchTransaction.__Your_batch_file_hasbeen_successfully Your_batch_file_hasbeen_successfully { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Payments_Cash_CompleteTransaction_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_Cash_CompleteTransaction_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/iq5n0z-_l0OCFiaX_BeByg", DisplayName = "Payments_Cash_CompleteTransaction_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Payments_Payment_Menthod
    {
        public class __Payments_Payment_Menthod_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_Payment_Menthod_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/B1vZ-Yog_ken1Ty84aMQnQ", DisplayName = "Payments_Payment_Menthod_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Payments_Payment_Menthod : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_Payment_Menthod(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/iVAet9KDf0aaeT6IMdWlhg", DisplayName = "Payments_Payment_Menthod", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Payments_Payment_Menthod_Input = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_Payment_Menthod.__Payments_Payment_Menthod_Input(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Payments_Payment_Menthod.__Payments_Payment_Menthod_Input Payments_Payment_Menthod_Input { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Payments_Refund_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_Refund_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/OoJpwqLuCk26azeu9EqgSg", DisplayName = "Payments_Refund_Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Phone_Country_Code : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Phone_Country_Code(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/MFTzB-v6aEy0Vrki-ssYyQ", DisplayName = "Phone Country Code", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Phone_Number : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Phone_Number(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Qts96j8NkEm9kOt8YtLHrg", DisplayName = "Phone Number", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item
    {
        public class __Add_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Add_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/aDOvbIAEaU6vcIcz5-qeRg", DisplayName = "Add Item", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item
    {
        public class __Add_Preset_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Add_Preset_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/8qZWxT3GwEiHwvqNRYzyEw", DisplayName = "Add Preset Item", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item
    {
        public class __No_Items_Found : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __No_Items_Found(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/twdV76KqIUe3ls8yR3Vl8A", DisplayName = "No Items Found", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item
    {
        public class __Preset_Sale_Item_Success_Message : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Preset_Sale_Item_Success_Message(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/nMJ9hDYHPk-t9U-k3pVVdg", DisplayName = "Preset Sale Item Success Message", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item
    {
        public class __Preset_Sale_Item_Tax_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Preset_Sale_Item_Tax_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/AB3o-MMhQUuH0CA-u0KFVA", DisplayName = "Preset Sale Item Tax%", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item
    {
        public class __Sale_Item_Price : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sale_Item_Price(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/tLBBeCVmpEex7wv2Fh88Qg", DisplayName = "Sale Item Price", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item
    {
        public class __Search_Preset_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Search_Preset_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/3b-iKfQsvEqiLM43YVZFyg", DisplayName = "Search Preset Item", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item
    {
        public class __Select_Preset_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Select_Preset_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/hdAVPS0Ohku9iRO6X1hznA", DisplayName = "Select Preset Item", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Preset_Sale_Item : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Preset_Sale_Item(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/uZWswJDBjE25qGMCt8lSAA", DisplayName = "Preset Sale Item", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Add_Item = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Add_Item(screenDescriptor, this);
                Add_Preset_Item = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Add_Preset_Item(screenDescriptor, this);
                No_Items_Found = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__No_Items_Found(screenDescriptor, this);
                Preset_Sale_Item_Success_Message = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Preset_Sale_Item_Success_Message(screenDescriptor, this);
                Preset_Sale_Item_Tax_ = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Preset_Sale_Item_Tax_(screenDescriptor, this);
                Sale_Item_Price = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Sale_Item_Price(screenDescriptor, this);
                Search_Preset_Item = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Search_Preset_Item(screenDescriptor, this);
                Select_Preset_Item = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Select_Preset_Item(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Add_Item Add_Item { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Add_Preset_Item Add_Preset_Item { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__No_Items_Found No_Items_Found { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Preset_Sale_Item_Success_Message Preset_Sale_Item_Success_Message { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Preset_Sale_Item_Tax_ Preset_Sale_Item_Tax_ { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Sale_Item_Price Sale_Item_Price { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Search_Preset_Item Search_Preset_Item { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Preset_Sale_Item.__Select_Preset_Item Select_Preset_Item { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Recurring_Payment_Frequency : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Recurring_Payment_Frequency(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/uDbKvuGf-kSMPrsWimsDJg", DisplayName = "Recurring Payment Frequency", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Refund_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Refund_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/mExnZ7fwkEOM0y7FyZs2PA", DisplayName = "Refund Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Refund_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Refund_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/OYIKf_GCW0Gh2G6riEiL3A", DisplayName = "Refund Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Sale_Item_Name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sale_Item_Name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/day1HQMt8k2d4CDANLwUUA", DisplayName = "Sale Item Name", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Sale_Item_Price : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sale_Item_Price(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/fyFNx95wZEiTgjK9RHHlgw", DisplayName = "Sale Item Price", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Sale_Item_Tax_Rate
    {
        public class __Sale_Item_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sale_Item_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Pmp54FFcnEqeYraa0EM64A", DisplayName = "Sale Item Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Sale_Item_Tax_Rate : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sale_Item_Tax_Rate(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/odD7M_kTLUafBI0DlIXpRQ", DisplayName = "Sale Item Tax Rate", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Sale_Item_Input = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Sale_Item_Tax_Rate.__Sale_Item_Input(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Sale_Item_Tax_Rate.__Sale_Item_Input Sale_Item_Input { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Sale_Items_Arrow_Button : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Sale_Items_Arrow_Button(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/tghGRV6XeE-076DtYno7mQ", DisplayName = "Sale Items Arrow Button", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Search_Customer
    {
        public class __Customer_Name : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Customer_Name(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/4wnmij-KgkCN_wL0MApVdw", DisplayName = "Customer Name", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Search_Customer
    {
        public class __Payments_SearchCustomer_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_SearchCustomer_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/9yjTdqjwW0uOPGyeuI87gw", DisplayName = "Payments_SearchCustomer_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Search_Customer : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Search_Customer(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/MdF-CaV8JUGC7GXW5v0xew", DisplayName = "Search Customer", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Customer_Name = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Search_Customer.__Customer_Name(screenDescriptor, this);
                Payments_SearchCustomer_Input = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Search_Customer.__Payments_SearchCustomer_Input(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Search_Customer.__Customer_Name Customer_Name { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Search_Customer.__Payments_SearchCustomer_Input Payments_SearchCustomer_Input { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Search_Merchant
    {
        public class __Label_MerchantName : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Label_MerchantName(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/0sYVlA91q0eMe2-FJMTqKA", DisplayName = "Label MerchantName", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments._Search_Merchant
    {
        public class __Payments_Search_Merchant_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Payments_Search_Merchant_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/UCQjT7WCLkmINx7MggnYvA", DisplayName = "Payments_Search Merchant_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Search_Merchant : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Search_Merchant(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/pAEht5SP_0yWDkAQIEGopw", DisplayName = "Search Merchant", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
                Label_MerchantName = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Search_Merchant.__Label_MerchantName(screenDescriptor, this);
                Payments_Search_Merchant_Input = new _Implementation._Deluxe_Payments_Platform._DPP_Payments._Search_Merchant.__Payments_Search_Merchant_Input(screenDescriptor, this);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Search_Merchant.__Label_MerchantName Label_MerchantName { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments._Search_Merchant.__Payments_Search_Merchant_Input Payments_Search_Merchant_Input { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Setup_Recurring_Payment : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Setup_Recurring_Payment(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/vwfhZKGdc0K7MFcu6dLvYA", DisplayName = "Setup Recurring Payment", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Success_Message : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Success_Message(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/DqWDmJMBp0eAJeJCrZb_cQ", DisplayName = "Success Message", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_Payments
    {
        public class __Total : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Total(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/24FU_F_Tt0qbz72owu2feQ", DisplayName = "Total", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform
    {
        public class __DPP_Payments : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __DPP_Payments()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/mSXdD02ZhEGZhTjqixcURw", DisplayName = "DPP_Payments", Screen = this};
                Add_Preset_Item = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Add_Preset_Item(this, null);
                Add_Quick_Item = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Add_Quick_Item(this, null);
                Additional_Fields = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Additional_Fields(this, null);
                Authorization_Code = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Authorization_Code(this, null);
                Charge_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Charge_Button(this, null);
                Close_Toast_Message = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Close_Toast_Message(this, null);
                Country = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Country(this, null);
                Create_Vault_Customer = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Create_Vault_Customer(this, null);
                Customer_Address = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_Address(this, null);
                Customer_City = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_City(this, null);
                Customer_Info_Arrow_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_Info_Arrow_Button(this, null);
                Customer_State = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_State(this, null);
                Customer_Zip_Code = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_Zip_Code(this, null);
                Email = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Email(this, null);
                Enter_Alternate_Shipping_Address = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Enter_Alternate_Shipping_Address(this, null);
                First_Name = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__First_Name(this, null);
                Last_Name = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Last_Name(this, null);
                New_Sale_Item_Added = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__New_Sale_Item_Added(this, null);
                OrderSummary = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__OrderSummary(this, null);
                Payment_Info = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payment_Info(this, null);
                PaymentLink_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__PaymentLink_Button(this, null);
                Payments_Label = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_Label(this, null);
                Payments_BatchTransaction = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_BatchTransaction(this, null);
                Payments_Cash_CompleteTransaction_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_Cash_CompleteTransaction_Button(this, null);
                Payments_Payment_Menthod = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_Payment_Menthod(this, null);
                Payments_Refund_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_Refund_Button(this, null);
                Phone_Country_Code = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Phone_Country_Code(this, null);
                Phone_Number = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Phone_Number(this, null);
                Preset_Sale_Item = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Preset_Sale_Item(this, null);
                Recurring_Payment_Frequency = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Recurring_Payment_Frequency(this, null);
                Refund_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Refund_Button(this, null);
                Refund_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Refund_Button(this, null);
                Sale_Item_Name = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Sale_Item_Name(this, null);
                Sale_Item_Price = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Sale_Item_Price(this, null);
                Sale_Item_Tax_Rate = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Sale_Item_Tax_Rate(this, null);
                Sale_Items_Arrow_Button = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Sale_Items_Arrow_Button(this, null);
                Search_Customer = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Search_Customer(this, null);
                Search_Merchant = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Search_Merchant(this, null);
                Setup_Recurring_Payment = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Setup_Recurring_Payment(this, null);
                Success_Message = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Success_Message(this, null);
                Total = new _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Total(this, null);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Add_Preset_Item Add_Preset_Item { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Add_Quick_Item Add_Quick_Item { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Additional_Fields Additional_Fields { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Authorization_Code Authorization_Code { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Charge_Button Charge_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Close_Toast_Message Close_Toast_Message { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Country Country { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Create_Vault_Customer Create_Vault_Customer { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_Address Customer_Address { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_City Customer_City { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_Info_Arrow_Button Customer_Info_Arrow_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_State Customer_State { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Customer_Zip_Code Customer_Zip_Code { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Email Email { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Enter_Alternate_Shipping_Address Enter_Alternate_Shipping_Address { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__First_Name First_Name { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Last_Name Last_Name { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__New_Sale_Item_Added New_Sale_Item_Added { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__OrderSummary OrderSummary { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payment_Info Payment_Info { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__PaymentLink_Button PaymentLink_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_Label Payments_Label { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_BatchTransaction Payments_BatchTransaction { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_Cash_CompleteTransaction_Button Payments_Cash_CompleteTransaction_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_Payment_Menthod Payments_Payment_Menthod { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Payments_Refund_Button Payments_Refund_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Phone_Country_Code Phone_Country_Code { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Phone_Number Phone_Number { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Preset_Sale_Item Preset_Sale_Item { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Recurring_Payment_Frequency Recurring_Payment_Frequency { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Refund_Button Refund_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Refund_Button Refund_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Sale_Item_Name Sale_Item_Name { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Sale_Item_Price Sale_Item_Price { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Sale_Item_Tax_Rate Sale_Item_Tax_Rate { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Sale_Items_Arrow_Button Sale_Items_Arrow_Button { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Search_Customer Search_Customer { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Search_Merchant Search_Merchant { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Setup_Recurring_Payment Setup_Recurring_Payment { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Success_Message Success_Message { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_Payments.__Total Total { get; private set; }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_SideMenu
    {
        public class __CV_CreateNewCustomer_State_Input : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __CV_CreateNewCustomer_State_Input(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/nLLiHky_mE2W9zW4Zxh1dA", DisplayName = "CV_CreateNewCustomer_State_Input", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_SideMenu
    {
        public class __Menu_CustomerVault : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Menu_CustomerVault(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/7ZRzK70Cqk-Rr9Ow2t8Xsg", DisplayName = "Menu_CustomerVault", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform._DPP_SideMenu
    {
        public class __Menu_Payments : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Menu_Payments(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/Sg9UA1KxIUSJN2zZFfkStQ", DisplayName = "Menu_Payments", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Deluxe_Payments_Platform
    {
        public class __DPP_SideMenu : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __DPP_SideMenu()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "qnsGvNsFSUiRvH4oM-Q7Tg/VvoGClPDh0K4rusj6HPbUw", DisplayName = "DPP_SideMenu", Screen = this};
                CV_CreateNewCustomer_State_Input = new _Implementation._Deluxe_Payments_Platform._DPP_SideMenu.__CV_CreateNewCustomer_State_Input(this, null);
                Menu_CustomerVault = new _Implementation._Deluxe_Payments_Platform._DPP_SideMenu.__Menu_CustomerVault(this, null);
                Menu_Payments = new _Implementation._Deluxe_Payments_Platform._DPP_SideMenu.__Menu_Payments(this, null);
            }

            public _Implementation._Deluxe_Payments_Platform._DPP_SideMenu.__CV_CreateNewCustomer_State_Input CV_CreateNewCustomer_State_Input { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_SideMenu.__Menu_CustomerVault Menu_CustomerVault { get; private set; }

            public _Implementation._Deluxe_Payments_Platform._DPP_SideMenu.__Menu_Payments Menu_Payments { get; private set; }
        }
    }
}